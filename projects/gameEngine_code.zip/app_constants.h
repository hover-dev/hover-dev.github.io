#ifndef APP_CONSTS
#define APP_CONSTS

#define APP_NAME L"A Game"
#define WINDOW_NAME L"A Game: The Adventure"
#define WIN_WIDTH 1024
#define WIN_HEIGHT 768
#define WIN_ASPECT (FLOAT)WIN_WIDTH/(FLOAT)WIN_HEIGHT

#define KEY_DOWN(dik_code) (keystate[dik_code] & 0x80)

// Game states
#define STATE_PLAYING		0
#define STATE_TYPING		1

// Font variables
#define CHAT_FONT_HEIGHT	21

#endif