#include "camera.h"

Camera::Camera()
{
	yaw = 0.0f;
	pitch = 0.0f;
	Position = LOC_START;
	Direction = VEC_FORWARD * NUM_MOVE_SPEED;
	D3DXMatrixIdentity(&matViewRotate);
	BufferCache = NULL;
	skybox = NULL;
}

Camera::Camera(LPCHARACTER newCharacter)
{
	yaw = 0.0f;
	pitch = 0.0f;
	Position = newCharacter->GetPosition() + newCharacter->GetHeight();
	Direction = VEC_FORWARD * NUM_MOVE_SPEED;
	D3DXMatrixIdentity(&matViewRotate);
	character = newCharacter;
	BufferCache = new BufferStorage();
	LoadMesh(&skybox, &material, &texture, &numMaterials, L"meshes/skybox.x"); 
	material->Emissive.r = 1.0f;
	material->Emissive.g = 1.0f;
	material->Emissive.b = 1.0f;
}

Camera::~Camera()
{
	delete character;
	(*texture)->Release();
}

void Camera::LookLeft()		{ yaw -= NUM_TURN_SPEED; UpdateDirection(); }
void Camera::LookRight()	{ yaw += NUM_TURN_SPEED; UpdateDirection(); }
void Camera::LookUp()		{ pitch += NUM_TURN_SPEED; UpdateDirection(); }
void Camera::LookDown()		{ pitch -= NUM_TURN_SPEED; UpdateDirection(); }

void Camera::MoveForward()
{
	D3DXVECTOR3 movement = D3DXVECTOR3(Direction.x, 0.0f, Direction.z);
	D3DXVec3Normalize(&movement, &movement);
	movement *= NUM_MOVE_SPEED;
	
	this->MovementCollisions(movement);
}
void Camera::MoveBack()
{
	D3DXVECTOR3 movement = D3DXVECTOR3(Direction.x, 0.0f, Direction.z);
	D3DXVec3Normalize(&movement, &movement);
	movement *= NUM_MOVE_SPEED;
	
	this->MovementCollisions(-movement);
}
void Camera::MoveLeft()
{
	D3DXVECTOR3 left;
	D3DXVec3Cross(&left, &Direction, &VEC_UP);
	
	this->MovementCollisions(left);
}
void Camera::MoveRight()
{
	D3DXVECTOR3 left;
	D3DXVec3Cross(&left, &Direction, &VEC_UP);

	this->MovementCollisions(-left);
}

void Camera::UpdateDirection()
{
	if (pitch > NUM_MAX_PITCH)
		pitch = NUM_MAX_PITCH;
	if (pitch < -NUM_MAX_PITCH)
		pitch = -NUM_MAX_PITCH;
	D3DXMatrixRotationYawPitchRoll(&matViewRotate, yaw, pitch, 0.0f);
	D3DXVec3TransformCoord(&Direction, &VEC_FORWARD, &matViewRotate);
	Direction *= NUM_MOVE_SPEED;
}

D3DXVECTOR3 Camera::GetDirection()	{ return Direction; }
D3DXVECTOR3 Camera::GetLookat()		{ return (Position + Direction); }

void Camera::PullCharacter()
{
	character->SetPosDir(Position, Direction);
}

void Camera::DrawSkybox()
{
	// Create the translation matrix
	D3DXMATRIX matTranslate;
	D3DXMatrixTranslation(&matTranslate, Position.x, Position.y, Position.z);

	// Rotate and move the mesh
	d3dDevice->SetTransform(D3DTS_WORLD, &matTranslate);

	for(DWORD i = 0; i < numMaterials; i++)
	{
		d3dDevice->SetMaterial(&material[i]);
		if (texture[i] != NULL)
			d3dDevice->SetTexture(0, texture[i]);
		skybox->DrawSubset(i);
	}

	// Reset the world view for the next draw call
	D3DXMATRIX matID;
	D3DXMatrixIdentity(&matID);  
	d3dDevice->SetTransform(D3DTS_WORLD, &matID);  
}