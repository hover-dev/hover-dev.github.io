#ifndef CAMERA
#define CAMERA

#include <d3d9.h>
#include <d3dx9.h>
#include "collision_detection.h" // Camera inherits Collidable

// The near and far clipping planes
#define NUM_VIEW_NEAR 0.1f // HACK: The player should actually be moved away from the wall normal during collision detection.  Visual glitches appear with a small near plane value and it still doesn't fix the problem.
#define NUM_VIEW_FAR 300.0f

//-----------------------------------------------------------------------------
// Class: Camera
// Desc: Logic for moving the client's player view
//-----------------------------------------------------------------------------
class Camera : public Collidable
{
public:
	// Constructors and destructors
	Camera();
	Camera(LPCHARACTER newCharacter);
	~Camera();

	// Looking
	void LookLeft();
	void LookRight();
	void LookUp();
	void LookDown();

	// Moving
	void MoveForward();
	void MoveBack();
	void MoveLeft();
	void MoveRight();

	// Get
	D3DXVECTOR3 GetDirection();
	D3DXVECTOR3 GetLookat();

	void PullCharacter();	// Move the character to the camera location
	void DrawSkybox();		// Draw the skybox

private:
	// View data
	float					yaw;
	float					pitch;
	D3DXMATRIX				matViewRotate;
	D3DXVECTOR3				Direction;

	// Skybox variables
	LPD3DXMESH				skybox;
	D3DMATERIAL9*			material;
	LPDIRECT3DTEXTURE9*		texture;
	DWORD					numMaterials;

	void UpdateDirection();	// Logic for changing direction
};

typedef Camera* LPCAMERA;

#endif