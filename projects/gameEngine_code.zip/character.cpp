#include "character.h"

Character::Character()
{
	Position = LOC_START;
	Direction = D3DXVECTOR3(0.0f, 0.0f, -NUM_MOVE_SPEED);
	height = NUM_PLAYER_HEIGHT;
	bodySubsets[INDEX_BODY] = SUBSET_BODY;
	bodySubsets[INDEX_HEAD] = SUBSET_HEAD_1;
	bodySubsets[INDEX_PANTS] = SUBSET_LEATHER_PANTS;
	bodySubsets[INDEX_TORSO] = SUBSET_LEATHER_CHEST;
}

Character::Character(const wchar_t* fileName)
{
	Position = LOC_START;
	Direction = D3DXVECTOR3(0.0f, 0.0f, -NUM_MOVE_SPEED);
	height = NUM_PLAYER_HEIGHT;
	bodySubsets[INDEX_BODY] = SUBSET_BODY;
	bodySubsets[INDEX_HEAD] = SUBSET_HEAD_1;
	bodySubsets[INDEX_PANTS] = SUBSET_LEATHER_PANTS;
	bodySubsets[INDEX_TORSO] = SUBSET_LEATHER_CHEST;
	InitMesh(fileName);
}

Character::~Character()
{
	(*texture)->Release();
}

D3DXVECTOR3 Character::GetPosition()	{ return Position; }
D3DXVECTOR3 Character::GetDirection()	{ return Direction; }

void Character::SetPosDir(D3DXVECTOR3 camPosition, D3DXVECTOR3 camDirection)
{
	Position = camPosition - D3DXVECTOR3(0.0f, height, 0.0f);
	Direction = camDirection;
}

D3DXVECTOR3 Character::GetHeight()
{
	return D3DXVECTOR3(0.0f, height, 0.0f);
}

void Character::InitMesh(const wchar_t* fileName)
{
	LoadMesh(&mesh, &material, &texture, &numMaterials, fileName);

	// Initialize the bounding box
	CUSTOM_VERTEX* pVertex = 0;
	mesh->LockVertexBuffer(0, (PVOID*)&pVertex);
	D3DXComputeBoundingBox((D3DXVECTOR3*)pVertex, mesh->GetNumVertices(), sizeof(CUSTOM_VERTEX), &bbMin, &bbMax);
	mesh->UnlockVertexBuffer();
}

void Character::DrawMesh()
{
	// Create the rotation matrix
	//			(doesn't work quite right just yet)
	//
	//D3DXVECTOR3 default_direction = D3DXVECTOR3(0.0f, 0.0f, -1.0f);
	//D3DXVECTOR3 xz_direction = D3DXVECTOR3(Direction.x, 0.0f, Direction.z);
	//float angle = D3DXVec3Dot(&default_direction, &xz_direction);
	//angle /= (D3DXVec3Length(&default_direction)*D3DXVec3Length(&xz_direction));
	//angle = acos(angle);

	//if (Direction.x > 0) // Dot product has no concept of which way you're rotating, so add a half-rotation if it returns the inverse angle
	//	angle += 3.14159265f;

	//D3DXMATRIX matRotation;
	//D3DXMatrixRotationY(&matRotation, angle);
	
	// Create the translation matrix
	D3DXMATRIX matTranslate;
	D3DXMatrixTranslation(&matTranslate, Position.x, Position.y, Position.z);

	// Rotate and move the mesh
	d3dDevice->SetTransform(D3DTS_WORLD, &matTranslate);//&(matRotation * matTranslate));

	// Draw the mesh
	for (int i = 0; i < SUBSETS_TO_DRAW; i++)
	{
		d3dDevice->SetMaterial(&material[bodySubsets[i]]);
		if (*texture != NULL && texture[bodySubsets[i]] != NULL)
			d3dDevice->SetTexture(0, texture[bodySubsets[i]]);
		mesh->DrawSubset(bodySubsets[i]);
	}

	// Reset the world view for the next draw call
	D3DXMATRIX matID;
	D3DXMatrixIdentity(&matID);  
	d3dDevice->SetTransform(D3DTS_WORLD, &matID);  
}












AnimatedMesh::AnimatedMesh()
{
	TopFrame = NULL;
	AnimationController = NULL;
	FinalMatrices = NULL;
}

AnimatedMesh::~AnimatedMesh()
{
	Release();
}

void AnimatedMesh::InitMesh(const wchar_t* fileName)
{
	D3DXLoadMeshHierarchyFromX(fileName,
							   D3DXMESH_MANAGED,
							   d3dDevice,
							   &MeshAllocator,
							   NULL,
							   &TopFrame,
							   &AnimationController);

	FinalMatrices = new D3DXMATRIX[MeshAllocator.MaxFrames];
	ZeroMemory(FinalMatrices, sizeof(D3DXMATRIX) * MeshAllocator.MaxFrames);
	// end of LoadAnimatedMesh

	LinkFrames((CUSTOM_FRAME*)TopFrame);
}

void AnimatedMesh::DrawMesh()
{
	// TODO: When animated meshes are working, set location and direction and set to identity matrix at the end

	// Increment the time in the animation
	if(AnimationController)
	{
		static DWORD Time = GetTickCount();

		// move the animation forward by the elapsed time
		AnimationController->AdvanceTime((GetTickCount() - Time) * 0.001f, NULL);

		// reset Time for the next time through
		Time = GetTickCount();
	}

	// Update the frame matrices and mesh containers to the new time
	UpdateFrames((CUSTOM_FRAME*)TopFrame, NULL);
	UpdateMeshContainers((CUSTOM_FRAME*)TopFrame);

	// Render the mesh containers
	DrawAnimatedMesh((CUSTOM_FRAME*)TopFrame);
}

void AnimatedMesh::Release()
{
	SAFE_RELEASE(AnimationController);
	D3DXFrameDestroy(TopFrame, &MeshAllocator);
	SAFE_DELETE_ARRAY(FinalMatrices);
}

void AnimatedMesh::LinkFrames(CUSTOM_FRAME* pFrame)
{
    // cast the pFrame's mesh container pointer to a CUSTOM_MESHCONTAINER*
    CUSTOM_MESHCONTAINER* pMeshContainer = (CUSTOM_MESHCONTAINER*)pFrame->pMeshContainer;

    // if there is a mesh container and if it has skin info...
    if(pMeshContainer && pMeshContainer->pSkinInfo)
    {
        // loop through each frame in the mesh container
        for(UINT i = 0; i < pMeshContainer->pSkinInfo->GetNumBones(); i++)
        {
            CUSTOM_FRAME* pTempFrame;    // a temporary frame pointer

            // find each frame by name
            pTempFrame = (CUSTOM_FRAME*)D3DXFrameFind(TopFrame,
                                                  pMeshContainer->pSkinInfo->GetBoneName(i));
            // and set up a pointer to it
            pMeshContainer->ppFrameMatrices[i] = &pTempFrame->CombTransformationMatrix;
        }
    }

    // run for all siblings
    if(pFrame->pFrameSibling)
        LinkFrames((CUSTOM_FRAME*)pFrame->pFrameSibling);

    // run for the first child (which will then run all other children)
    if(pFrame->pFrameFirstChild)
        LinkFrames((CUSTOM_FRAME*)pFrame->pFrameFirstChild);
}

void AnimatedMesh::UpdateFrames(CUSTOM_FRAME* pFrame, D3DXMATRIX* pParentMatrix)
{
    // combine the frame's matrix with the parent's matrix, if any
    if(pParentMatrix)
        pFrame->CombTransformationMatrix = pFrame->TransformationMatrix * *pParentMatrix;
    else
        pFrame->CombTransformationMatrix = pFrame->TransformationMatrix;

    // run for all siblings
    if(pFrame->pFrameSibling)
        UpdateFrames((CUSTOM_FRAME*)pFrame->pFrameSibling, pParentMatrix);

    // run for the first child (which will then run all other children)
    if(pFrame->pFrameFirstChild)
        UpdateFrames((CUSTOM_FRAME*)pFrame->pFrameFirstChild,
            &pFrame->CombTransformationMatrix);
}

void AnimatedMesh::UpdateMeshContainers(CUSTOM_FRAME* pFrame)
{
    // Cast the pFrame's mesh container pointer to a CUSTOM_MESHCONTAINER*
    CUSTOM_MESHCONTAINER* pMeshContainer = (CUSTOM_MESHCONTAINER*)pFrame->pMeshContainer;

    if(pMeshContainer && pMeshContainer->pSkinInfo)
    {
        UINT NumFrames = pMeshContainer->pSkinInfo->GetNumBones();    // find how many frames
        // For each frame in the mesh container...
        for(UINT i = 0; i < NumFrames; i++)
        {
            // Set FinalMatrices to that frame's offset matrix
            FinalMatrices[i] = *pMeshContainer->pSkinInfo->GetBoneOffsetMatrix(i);

            // Multiply that by the animated frame matrix
            FinalMatrices[i] *= *pMeshContainer->ppFrameMatrices[i];
        }

        void* pSrc = NULL;    // Void pointer to original mesh
        void* pDst = NULL;    // Void pointer to modified mesh

		// TODO: Will locking constantly slow things down?  If so, toss these into a BufferCache
        // Lock the two meshes
        pMeshContainer->MeshData.pMesh->LockVertexBuffer(NULL, &pSrc);
        pMeshContainer->pFinalMesh->LockVertexBuffer(NULL, &pDst);

        // Store the animated mesh into FinalMesh
        pMeshContainer->pSkinInfo->UpdateSkinnedMesh(FinalMatrices, NULL, pSrc, pDst);

        // Unlock the two meshes
        pMeshContainer->pFinalMesh->UnlockVertexBuffer();
        pMeshContainer->MeshData.pMesh->UnlockVertexBuffer();
    }

    // Run for all siblings
    if (pFrame->pFrameSibling)
        UpdateMeshContainers((CUSTOM_FRAME*)pFrame->pFrameSibling);

    // Run for the first child
    if (pFrame->pFrameFirstChild)
        UpdateMeshContainers((CUSTOM_FRAME*)pFrame->pFrameFirstChild);
}

void AnimatedMesh::DrawAnimatedMesh(CUSTOM_FRAME* pFrame)
{
	// Create the scaling matrix
	D3DXMATRIX matScale, matTranslate;
	D3DXMatrixTranslation(&matTranslate, 1.0f, -1.0f, 0);
	D3DXMatrixScaling(&matScale, 0.003f, 0.003f, 0.003f);

	// Scale the mesh
	d3dDevice->SetTransform(D3DTS_WORLD, &(matScale*matTranslate));

    // Cast the pFrame's mesh container pointer to a CUSTOM_MESHCONTAINER*
    CUSTOM_MESHCONTAINER* pMeshContainer = (CUSTOM_MESHCONTAINER*)pFrame->pMeshContainer;

    if(pMeshContainer)
    {
        // For each material...
        for(UINT i = 0; i < pMeshContainer->NumMaterials; i++)
        {
            // Set the material
            d3dDevice->SetMaterial(&pMeshContainer->pMaterials[i].MatD3D);
            // Set the texture
            d3dDevice->SetTexture(0, pMeshContainer->pTextures[i]);

            // Draw the subset
            pMeshContainer->pFinalMesh->DrawSubset(i);
        }
    }

    // run for all siblings
    if(pFrame->pFrameSibling)
        DrawAnimatedMesh((CUSTOM_FRAME*)pFrame->pFrameSibling);

    // run for the first child (which will then run all other children)
    if(pFrame->pFrameFirstChild)
        DrawAnimatedMesh((CUSTOM_FRAME*)pFrame->pFrameFirstChild);

	// Reset the world view for the next draw call
	D3DXMATRIX matID;
	D3DXMatrixIdentity(&matID);  
	d3dDevice->SetTransform(D3DTS_WORLD, &matID); 
}