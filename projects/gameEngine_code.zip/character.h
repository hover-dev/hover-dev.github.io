#ifndef CHARACTER
#define CHARACTER

#include <d3d9.h>
#include <d3dx9.h>
#include "graphics.h"			// Used to allocate animated meshes
#include "x_file_constants.h"	// Used to draw the proper character clothing subsets

#define LOC_START D3DXVECTOR3(0.0f, 10.0f, 0.0f)	// The default player start location

#define NUM_PLAYER_HEIGHT 1.0f	// The default player height
#define NUM_TURN_SPEED 0.05f	// Radians
#define NUM_MOVE_SPEED 0.15f	// Coordinates
#define NUM_MAX_PITCH 1.57f		// A limit on how far up and down you can look.  A little less than pi/2 radians

extern LPDIRECT3DDEVICE9 d3dDevice; // Needed for DrawMesh

//-----------------------------------------------------------------------------
// Class: Character
// Desc: Models, animations and server data for in-game character
//-----------------------------------------------------------------------------
class Character
{
public:
	// Constructors and destructors
	Character();
	Character(const wchar_t* fileName);
	~Character();

	// Get
	D3DXVECTOR3 GetPosition();
	D3DXVECTOR3 GetDirection();
	D3DXVECTOR3 GetHeight();

	// Set
	void SetPosDir(D3DXVECTOR3 camPosition, D3DXVECTOR3 camDirection);

	// Mesh initialization and drawing
	void InitMesh(const wchar_t* fileName);
	void DrawMesh();

private:
	// World data variables
	D3DXVECTOR3				Position;
	D3DXVECTOR3				Direction;
	float					height;

	// Mesh and texture variables
	LPD3DXMESH				mesh;
	D3DMATERIAL9*			material;
	LPDIRECT3DTEXTURE9*		texture;
	DWORD					numMaterials;

	// Gameplay variables
	int						bodySubsets[SUBSETS_TO_DRAW];

	// Bounding box variables
	D3DXVECTOR3				bbMin;
	D3DXVECTOR3				bbMax;
};

typedef Character* LPCHARACTER;

//-----------------------------------------------------------------------------
// Class: AnimatedMesh
// Desc: A class to encompass animated models to be used for characters
//-----------------------------------------------------------------------------
class AnimatedMesh
{
public:
	// Constructors and destructors
	AnimatedMesh();
	~AnimatedMesh();

	// Mesh initialization and drawing 
	void InitMesh(const wchar_t* fileName);
	void DrawMesh();

	// Deallocation
	void Release();

private:
	// Mesh data
	LPD3DXFRAME					TopFrame;
	LPD3DXANIMATIONCONTROLLER	AnimationController;
	D3DXMATRIX*					FinalMatrices;
	MeshAllocation				MeshAllocator;

	// Mesh functions
	void LinkFrames(CUSTOM_FRAME* pFrame);
	void UpdateFrames(CUSTOM_FRAME* pFrame, D3DXMATRIX* pParentMatrix);
	void UpdateMeshContainers(CUSTOM_FRAME* pFrame);
	void DrawAnimatedMesh(CUSTOM_FRAME* pFrame);
};

typedef AnimatedMesh* LPANIMATEDMESH;

#endif