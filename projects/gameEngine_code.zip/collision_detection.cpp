#include "collision_detection.h"

Collidable::Collidable()
{
	character = new Character();
	BufferCache = new BufferStorage();
}
Collidable::~Collidable()
{
	delete character;
	delete BufferCache;
}

D3DXVECTOR3 Collidable::GetPosition()	{ return Position; }

void Collidable::ApplyGravity()
{
	bool fall = true;
	int meshCount = MeshListSize;

	// For each mesh you may collide with
	while (meshCount > 0)
	{
		BOOL hit = 0;
		DWORD fIndex, hitCount;
		float u, v, dist;
		LPD3DXBUFFER hitList;
		D3DXIntersect(MeshList,
					&(character->GetPosition()),
					&VEC_GRAVITY,
					&hit,
					&fIndex,
					&u,
					&v,
					&dist,
					&hitList,
					&hitCount);

		// If you're about to hit the ground vertically
		if (hit && (dist <= 1))
		{
			// Move to the ground and don't fall
			Position += (VEC_GRAVITY * dist);
			Position += VEC_FUDGE;
			fall = false;
		}

		// If there's no ground below you, you can't be falling toward it
		if (!hit)
			fall = false;

		meshCount -= 1;
	}

	if (fall)
		Position += VEC_GRAVITY;

	this->PullCharacter();
}

void Collidable::MovementCollisions(D3DXVECTOR3 direction)
{
	bool move = true;
	int meshCount = MeshListSize;

	// For each mesh you may collide with
	while (meshCount > 0)
	{
		BOOL hit = 0;
		DWORD fIndex, hitCount;
		float u, v, dist;
		LPD3DXBUFFER hitList;
		D3DXIntersect(MeshList,
					&(character->GetPosition()),
					&direction,
					&hit,
					&fIndex,
					&u,
					&v,
					&dist,
					&hitList,
					&hitCount);

		// If you will collide with something horizontally
		if (hit && (dist <= 1))
		{
			// Find the normal to see if it's too steep to scale
			CUSTOM_VERTEX v1, v2, v3;
			WORD iv1, iv2, iv3;

			CUSTOM_VERTEX* pVertex;
			WORD* indexBuffer;
			
			// If the buffers aren't in cache...
			if (MeshList != BufferCache->Mesh)
			{
				// Copy the mesh pointer
				BufferCache->Mesh = MeshList;

				// Process the index buffer
				MeshList->LockIndexBuffer(D3DLOCK_READONLY,
										(LPVOID*)&indexBuffer);
				iv1 = indexBuffer[fIndex*3 + 0];
				iv2 = indexBuffer[fIndex*3 + 1];
				iv3 = indexBuffer[fIndex*3 + 2];

				// Copy the index buffer to the cache
				BufferCache->CopyIB(indexBuffer, (MeshList->GetNumFaces()*3));

				MeshList->UnlockIndexBuffer();

				// Process the vertex buffer
				MeshList->LockVertexBuffer(D3DLOCK_READONLY,
										(PVOID*)&pVertex);
				v1 = pVertex[iv1];
				v2 = pVertex[iv2];
				v3 = pVertex[iv3];

				// Copy the vertex buffer to our cache
				BufferCache->CopyVB(pVertex, (MeshList->GetNumVertices()));
				
				MeshList->UnlockVertexBuffer();
			}
			// If they are in cache, point to their data
			else
			{
				indexBuffer = BufferCache->GetIB();
				iv1 = *(WORD*)(indexBuffer + fIndex*3 + 0);
				iv2 = *(WORD*)(indexBuffer + fIndex*3 + 1);
				iv3 = *(WORD*)(indexBuffer + fIndex*3 + 2);

				pVertex = BufferCache->GetVB();
				v1 = pVertex[iv1];
				v2 = pVertex[iv2];
				v3 = pVertex[iv3];
			}
			
			// Find the normal of the polygon intersected
			D3DXVECTOR3 axis1 = subtractCustomVertices(v1, v2);
			D3DXVECTOR3 axis2 = subtractCustomVertices(v3, v2);
			D3DXVECTOR3 normal;
			D3DXVec3Cross(&normal, &axis1, &axis2);
			D3DXVec3Normalize(&normal, &normal);

			// Because we're only dealing with movement on the x/z plane,
			// and because we only care about the y value next, the normal
			// y must be positive or else the normal is facing the wrong
			// way.  A wrong facing normal is easily fixed by flipping it
			// around the origin, which is equal to V *= -1.
			normal.y = abs(normal.y);

			// Don't move if the slope is too steep
			if (normal.y < NUM_SLOPE_TOLERANCE)
				move = false;

			D3DXIntersect(MeshList,
					&(character->GetPosition() + character->GetDirection()),
					&VEC_UP,
					&hit,
					&fIndex,
					&u,
					&v,
					&dist,
					&hitList,
					&hitCount);

			// If there's a change in height...
			if (hit)
			{
				// Move up despite steep slopes if the change in height is minor and if the angle is relatively up and down
				if ((move == false) && (dist < NUM_STEP_HEIGHT) && (normal.y == 0.0f))
					move = true;

				// Calculate the new height
				if (move)
					Position += (VEC_UP * dist);
			}

			// If we can't find anything above where we move...
			if (!hit)
			{
				D3DXIntersect(MeshList,
					&(character->GetPosition() + D3DXVECTOR3(0.0f, NUM_STEP_HEIGHT, 0.0f)),
					&direction,
					&hit,
					NULL, NULL, NULL, NULL, NULL, NULL);

				// If here's something above the maximum step height, we hit a wall
				if (hit) // We also already know the distance is close enough from previous steps
					move = false;

				// Otherwise, it's just a tiny bump
				//if (!hit)
				//	Position += VEC_FUDGE; // Just in case you move to the exact same level as the mesh
			}
		}

		meshCount -= 1;
	}

	// Climb up it if not too steep OR if the height incriment is small
	if (move)
	{
		Position += direction;
		this->PullCharacter();
	}
}

void Collidable::UpdateMeshList(LPD3DXMESH meshList, int listSize)
{
	// HACK: Test to see if terrain needs to be 2+ meshes.  If so, pass in multiple meshes.  When you do this, also increase the Buffer Cache to deal with more than 1 object.
	MeshList = meshList;
	MeshListSize = listSize;
}

void Collidable::PullCharacter()
{
	character->SetPosDir(Position, character->GetDirection());
}