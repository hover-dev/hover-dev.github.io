#ifndef COLLISION
#define COLLISION

#include <d3d9.h>
#include <d3dx9.h>
#include "graphics.h"	// Needs to be able to store buffers to get decent performance
#include "character.h"	// A collidable needs to be able to pull the character associated with it

#define VEC_UP D3DXVECTOR3(0.0f, 1.0f, 0.0f)		// A vector for up
#define VEC_FORWARD D3DXVECTOR3(0.0f, 0.0f, -1.0f)	// A vector for "forward"
#define VEC_FUDGE D3DXVECTOR3(0.0f, 0.1f, 0.0f)		// Used to make sure the collision rays don't start on a mesh
#define VEC_GRAVITY D3DXVECTOR3(0.0f, -0.4f, 0.0f)	// The force of gravity

#define NUM_SLOPE_TOLERANCE 0.85f	// The maximum y value of a plane's normal 
#define NUM_STEP_HEIGHT 0.35f		// The maximum height of a scalable slope that exceeds the slope tolerance

//-----------------------------------------------------------------------------
// Class: Npc
// Desc: Logic of a character's collisions, to be inherited by another class
//-----------------------------------------------------------------------------
class Collidable
{
public:
	// Get
	D3DXVECTOR3 GetPosition();
	
	// Collision logic
	void ApplyGravity();
	void MovementCollisions(D3DXVECTOR3 direction);
	void UpdateMeshList(LPD3DXMESH meshList, int listSize);

protected:
	// Constructors and destructors
	Collidable();
	~Collidable();

	// Called after collisions to put the character in the right position
	virtual void PullCharacter();

	// Character information
	D3DXVECTOR3			Position;
	LPCHARACTER			character;

	// Mesh information
	LPD3DXMESH			MeshList;
	int					MeshListSize;
	LPBUFFERSTORAGE		BufferCache;
};

#endif