#include "graphics.h"

D3DXVECTOR3 subtractCustomVertices(CUSTOM_VERTEX a, CUSTOM_VERTEX b)
{
	return D3DXVECTOR3(a.X - b.X, a.Y - b.Y, a.Z - b.Z);
}

void LoadMesh(LPD3DXMESH* out, D3DMATERIAL9** pMaterial, LPDIRECT3DTEXTURE9** pTexture, DWORD* numMaterials, const wchar_t* fileName)
{
	LPD3DXMESH tempMesh;

	// Initialize the mesh and textures for the current terrain
	LPD3DXBUFFER bufMaterial;
	D3DXLoadMeshFromX(fileName,
				D3DXMESH_SYSTEMMEM,
				d3dDevice,
				NULL,
				&bufMaterial,
				NULL,
				numMaterials,
				&tempMesh);

	D3DXMATERIAL* tempMaterials = (D3DXMATERIAL*)bufMaterial->GetBufferPointer();
	D3DMATERIAL9* material = new D3DMATERIAL9[*numMaterials];
	LPDIRECT3DTEXTURE9* texture = new LPDIRECT3DTEXTURE9[*numMaterials];

	for (DWORD i = 0; i < *numMaterials; i++)
	{
		material[i] = tempMaterials[i].MatD3D;
		material[i].Ambient = material[i].Diffuse;
		if(FAILED(D3DXCreateTextureFromFileA(d3dDevice,
										tempMaterials[i].pTextureFilename, // TODO: Cleanup.  Make it search for textures in the textures folder
										&texture[i])))
			texture[i] = NULL;
	}

	// Set the values pointed at to the values calculated
	*pMaterial = material;
	*pTexture = texture;

	// Change vertex format to conform to the custom vertex standards
	D3DVERTEXELEMENT9 decl[MAX_FVF_DECL_SIZE];
	D3DXDeclaratorFromFVF(CUSTOM_FVF, decl);
	tempMesh->CloneMesh(D3DXMESH_SYSTEMMEM, decl, d3dDevice, out);
}








BufferStorage::BufferStorage()
{
	Mesh = NULL;
	IB = NULL;
	VB = NULL;
}

BufferStorage::~BufferStorage()			{}

WORD* BufferStorage::GetIB()			{ return IB; }
CUSTOM_VERTEX* BufferStorage::GetVB()	{ return VB; }

void BufferStorage::CopyIB(WORD* indexBuffer, int size)
{
	IB = new WORD[size]; // Copy the index buffer to our cache
	memcpy(IB, indexBuffer, sizeof(WORD)*size);
}

void BufferStorage::CopyVB(CUSTOM_VERTEX* vertexBuffer, int size)
{
	VB = new CUSTOM_VERTEX[size];
	memcpy(VB, vertexBuffer, sizeof(CUSTOM_VERTEX)*size);
}











HRESULT MeshAllocation::CreateFrame(LPCSTR Name, LPD3DXFRAME* ppNewFrame)
{
	// Init the custom frame struct
	CUSTOM_FRAME* pFrame = new CUSTOM_FRAME;
	*ppNewFrame = pFrame;
	ZeroMemory(pFrame, sizeof(CUSTOM_FRAME));

	// Copy the name
	if(Name)
	{
		UINT len = strlen(Name) + 1;
		pFrame->Name = new char[len];
		memcpy(pFrame->Name, Name, len);
	}

	return S_OK;
}

HRESULT MeshAllocation::CreateMeshContainer(LPCSTR Name,
                               CONST D3DXMESHDATA* pMeshData,
                               CONST D3DXMATERIAL* pMaterials,
                               CONST D3DXEFFECTINSTANCE* pEffectInstances,
                               DWORD NumMaterials,
                               CONST DWORD* pAdjacency,
                               LPD3DXSKININFO pSkinInfo,
                               LPD3DXMESHCONTAINER* ppNewMeshContainer)
{
	// Init the mesh and container struct
	CUSTOM_MESHCONTAINER* pMeshContainer = new CUSTOM_MESHCONTAINER;
	*ppNewMeshContainer = pMeshContainer;
	ZeroMemory(pMeshContainer, sizeof(CUSTOM_MESHCONTAINER));

	// Exit if it's a patch or progressive mesh
	if(pMeshData->Type != D3DXMESHTYPE_MESH)
	{
		DestroyMeshContainer(pMeshContainer);
		return E_FAIL;
	}

	// Copy the name
	if(Name)
	{
		UINT len = strlen(Name) + 1;
		pMeshContainer->Name = new char[len];
		memcpy(pMeshContainer->Name, Name, len);
	}

	// Copy the mesh to the mesh container
	pMeshContainer->MeshData.Type = pMeshData->Type;
	pMeshContainer->MeshData.pMesh = pMeshData->pMesh;
	pMeshContainer->MeshData.pMesh->AddRef();

	// Copy the materials
	pMeshContainer->pMaterials = new D3DXMATERIAL[NumMaterials];
	for(DWORD i = 0; i < NumMaterials; i++)
	{
		pMeshContainer->pMaterials[i] = pMaterials[i];
		pMeshContainer->pMaterials[i].MatD3D.Ambient = pMaterials[i].MatD3D.Diffuse;
	}
	pMeshContainer->NumMaterials = NumMaterials;

	// Copy adjacency data
	pMeshContainer->pAdjacency = new DWORD[pMeshData->pMesh->GetNumFaces() * 3];
    memcpy(pMeshContainer->pAdjacency,
           pAdjacency,
           sizeof(DWORD) * pMeshData->pMesh->GetNumFaces() * 3);

	// Do various tasks requiring skin info
	if(pSkinInfo)
	{
		// Copy skin info
		pMeshContainer->pSkinInfo = pSkinInfo;
		pSkinInfo->AddRef();

		// Allocate memory for the frame matrix pointers
		pMeshContainer->ppFrameMatrices = new D3DXMATRIX*[pSkinInfo->GetNumBones()];
		for(DWORD i = 0; i < pSkinInfo->GetNumBones(); i++)
		{
			pMeshContainer->ppFrameMatrices[i] = NULL;
		}

		// Conveniently initialized MaxFrames
		MaxFrames = max(MaxFrames, (int)pMeshContainer->pSkinInfo->GetNumBones());
	}

	// Create a duplicate mesh
	pMeshContainer->MeshData.pMesh->CloneMesh(D3DXMESH_MANAGED,
											NULL,
											d3dDevice,
											&pMeshContainer->pFinalMesh);

	// Load the texture for each material (if any)
	pMeshContainer->pTextures = new LPDIRECT3DTEXTURE9[pMeshContainer->NumMaterials];
	for(DWORD i = 0; i < NumMaterials; i++)
	{
		pMeshContainer->pTextures[i] = 0;
		if(pMaterials[i].pTextureFilename)
		{
			D3DXCreateTextureFromFileA(d3dDevice,
									   pMeshContainer->pMaterials[i].pTextureFilename,
									   &pMeshContainer->pTextures[i]);
		}
	}

	return S_OK;
}

HRESULT MeshAllocation::DestroyFrame(LPD3DXFRAME pFrameToFree)
{
    // Free the name and the frame
    SAFE_DELETE_ARRAY(pFrameToFree->Name);
    SAFE_DELETE(pFrameToFree);

    return S_OK;
}

HRESULT MeshAllocation::DestroyMeshContainer(LPD3DXMESHCONTAINER pMeshContainerToFree)
{
    // cast the pointer to a CUSTOM_MESHCONTAINER
    CUSTOM_MESHCONTAINER* pMeshContainer = (CUSTOM_MESHCONTAINER*)pMeshContainerToFree;

    // free or release all allocated memory
    SAFE_DELETE_ARRAY(pMeshContainer->Name);
    SAFE_RELEASE(pMeshContainer->MeshData.pMesh);
    SAFE_RELEASE(pMeshContainer->pFinalMesh);
    SAFE_DELETE_ARRAY(pMeshContainer->pMaterials);
    SAFE_DELETE_ARRAY(pMeshContainer->pAdjacency);
    SAFE_RELEASE(pMeshContainer->pSkinInfo);
    SAFE_DELETE_ARRAY(pMeshContainer->ppFrameMatrices);
    for(UINT i = 0; i < pMeshContainer->NumMaterials; i++)
        SAFE_RELEASE(pMeshContainer->pTextures[i]);
    SAFE_DELETE(pMeshContainer);

    return S_OK;
}