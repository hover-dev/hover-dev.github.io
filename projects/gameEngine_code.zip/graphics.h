#ifndef GRAPHICS
#define GRAPHICS

#include <d3d9.h>
#include <d3dx9.h>
#include "safe_macros.h" // Releases safely in MeshAllocation

// Background and sprite colours
#define BACKGROUND_COLOUR	D3DCOLOR_XRGB(100,0,0)
#define TEXTBOX_MAX_ALPHA	127
#define TEXT_R				255
#define TEXT_G				255
#define TEXT_B				255

// Vertex formats
#define CUSTOM_FVF (D3DFVF_XYZ | D3DFVF_NORMAL | D3DFVF_TEX1)
struct CUSTOM_VERTEX {FLOAT X, Y, Z; D3DVECTOR NORMAL; FLOAT U, V;};

// Hierarchy animation formats
struct CUSTOM_FRAME : public D3DXFRAME
{
	 D3DXMATRIX CombTransformationMatrix;	// Include parent data in the transform
};
struct CUSTOM_MESHCONTAINER : public D3DXMESHCONTAINER
{
    D3DXMATRIX** ppFrameMatrices;			// A list of matrices to store current animation data
    LPD3DXMESH pFinalMesh;					// A duplicate of the mesh in it's current pose
    LPDIRECT3DTEXTURE9* pTextures;			// The mesh's textures
};

extern LPDIRECT3DDEVICE9 d3dDevice; // Needed for LoadMesh

// A helper to handle vertex subtraction under our FVF
D3DXVECTOR3 subtractCustomVertices(CUSTOM_VERTEX a, CUSTOM_VERTEX b);

// A helper to handle the complications of storing meshes, textures, and materials from file
void LoadMesh(LPD3DXMESH* out, D3DMATERIAL9** pMaterial, LPDIRECT3DTEXTURE9** pTexture, DWORD* numMaterials, const wchar_t* fileName);

//-----------------------------------------------------------------------------
// Class: BufferStorrage
// Desc: Stores index and vertex buffers for a mesh
//-----------------------------------------------------------------------------
class BufferStorage
{
public:
	// Constructors and destructors
	BufferStorage();
	~BufferStorage();

	// Get
	WORD* GetIB();
	CUSTOM_VERTEX* GetVB();

	// Set
	void CopyIB(WORD* indexBuffer, int size);
	void CopyVB(CUSTOM_VERTEX* indexBuffer, int size);

	// The mesh stored
	LPD3DXMESH			Mesh;

private:
	// The buffers stored
	WORD*				IB;
	CUSTOM_VERTEX*		VB;
};

typedef BufferStorage* LPBUFFERSTORAGE;

//-----------------------------------------------------------------------------
// Class: MeshAllocation
// Desc: Allocates data for animated meshes
//-----------------------------------------------------------------------------
class MeshAllocation : public ID3DXAllocateHierarchy
{
public:
	// Allocation
    STDMETHOD(CreateFrame)(LPCSTR Name, LPD3DXFRAME* ppNewFrame);
    STDMETHOD(CreateMeshContainer)(LPCSTR Name,
                                   CONST D3DXMESHDATA* pMeshData,
                                   CONST D3DXMATERIAL* pMaterials,
                                   CONST D3DXEFFECTINSTANCE* pEffectInstances,
                                   DWORD NumMaterials,
                                   CONST DWORD* pAdjacency,
                                   LPD3DXSKININFO pSkinInfo,
                                   LPD3DXMESHCONTAINER* ppNewMeshContainer);
    
	// Deallocation
	STDMETHOD(DestroyFrame)(LPD3DXFRAME pFrameToFree);
    STDMETHOD(DestroyMeshContainer)(LPD3DXMESHCONTAINER pMeshContainerToFree);

	// A calculated value used in initializing the animation
	int MaxFrames;
};

#endif