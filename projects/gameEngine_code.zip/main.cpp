//-----------------------------------------------------------------------------
// Using the window framework of Microsoft's CreateDevice.cpp
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// Heavily modified to include:
//  - Models (textured and animated)
//  - 3D collision detection
//  - Minimalistic GUI
//  - Client/server multiplayer
//-----------------------------------------------------------------------------
#define _WINSOCKAPI_
#include <d3d9.h>
#include <d3dx9.h>
#include <dinput.h>
#include <stdio.h>
#pragma warning( disable : 4996 ) // disable deprecated warning 
#include <strsafe.h>
#pragma warning( default : 4996 )
#include "app_constants.h"
#include "camera.h"
#include "npc.h"
#include "safe_macros.h"
#include "network.h"


//-----------------------------------------------------------------------------
// Function prototypes
//-----------------------------------------------------------------------------
void Print(char* string);
void InitGameplay();
void InitGraphics();
void InitLight();
void InitNetwork();
void DoInput();
void DoLogic();
void DoNetwork();
void DetectInput();
HRESULT InitD3D( HWND hWnd );
HRESULT InitDirectInput(HINSTANCE hInstance, HWND hWnd);
VOID Cleanup();
VOID RenderFrame();
LRESULT WINAPI MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam );
INT WINAPI wWinMain( HINSTANCE hInst, HINSTANCE, LPWSTR, INT );



//-----------------------------------------------------------------------------
// Global variables
//-----------------------------------------------------------------------------
// Direct3D
LPDIRECT3D9				D3D = NULL;			// Used to create the D3DDevice
LPDIRECT3DDEVICE9		d3dDevice = NULL;	// Our rendering device
LPD3DXSPRITE			d3dSprite = NULL;	// Our Direct3D Sprite interface

// Interface
LPD3DXFONT				font;		// A pointer to our font
static RECT				textbox;	// The box for text
LPDIRECT3DTEXTURE9		sprTextbox;	// The texture in the text box
int						textboxA;	// The textbox's current alpha value
char*					message;	// The message the player is typing

// Terrain
LPD3DXMESH				meshes[1];				// Terrain mesh and NPC mesh
D3DMATERIAL9*			material;				// List of terrain materials
LPDIRECT3DTEXTURE9*		texture;				// List of terrain textures
DWORD					numMaterials = NULL;	// Number of terrain materials

// DirectInput
LPDIRECTINPUT8			din;				// the pointer to our DirectInput interface
LPDIRECTINPUTDEVICE8	dinkeyboard;		// the pointer to the keyboard device
BYTE					keystate[256];		// the storage for the key-information

// Gameplay
LPCAMERA				camera = NULL;			// The camera for the player
LPCHARACTER				player = NULL;			// The player character
bool					clientsLock;			// Don't touch clients if it's being edited by RecvThread
LPANIMATEDMESH			animated = NULL;
int						state = STATE_PLAYING;	// The state the game is in
bool					returnPressed = false;	// Lets us check if return has been released

// Network
LPNETWORK				network = NULL;





//-----------------------------------------------------------------------------
// Name: Print
// Desc: Outputs a message to the game's console
//-----------------------------------------------------------------------------
void Print(char* string)
{
	// Move old messages up one
	for(int i = 9; i > 0; i--)
		network->messages[i] = network->messages[i-1];

	// Put the newest message in
	network->messages[0] = string;
}




//-----------------------------------------------------------------------------
// Name: DetectInput()
// Desc: Finds input via DirectInput
//-----------------------------------------------------------------------------
void InitGameplay()
{
	// Grab the player information
	player = new Character();
	camera = new Camera(player);

	// Create NPCs
	//npc = new Npc(D3DXVECTOR3(-7.5f, 10.0f, -3.5f), D3DXVECTOR3(1.0f, 0.0f, 0.0f), d3dDevice);
	//npc->UpdateMeshList(meshes[0], 1);
}




//-----------------------------------------------------------------------------
// Name: InitGraphics()
// Desc: Initializes the textures, vertex array, and index array
//-----------------------------------------------------------------------------
// TASK: Delayed.  Give NPCs an idle animation.  Animated models are not working properly.
// TASK: Implement a simple text database to create persistance among players
// TASK: Add chat capability and gameplay commands (HUD element exists, client sends data properly, server is having trouble getting the client pick it up when resent.  See the server for more info)
// MILESTONE: alpha v3.0

void InitGraphics()
{
	// Load the sprite interface
	D3DXCreateSprite(d3dDevice, &d3dSprite);

	// Load the text box background
	//D3DXCreateTextureFromFile(d3dDevice, L"grass.jpg", &sprTextbox);
	D3DXCreateTextureFromFileEx(d3dDevice,
								L"textbox.jpg",
								D3DX_DEFAULT,					// Default width
								D3DX_DEFAULT,					// Default height
								D3DX_DEFAULT,					// No mip mapping
								NULL,							// Regular usage
								D3DFMT_A8R8G8B8,				// 32-bit pixels with alpha
								D3DPOOL_MANAGED,				// Typical memory handling
								D3DX_DEFAULT,					// No filtering
								D3DX_DEFAULT,					// No mip filtering
								D3DCOLOR_XRGB(255, 0, 255),		// the hot-pink color key
								NULL,							// No image info struct
								NULL,							// Not using 256 colors
								&sprTextbox);

	// Load the font
	D3DXCreateFont(d3dDevice,
                   CHAT_FONT_HEIGHT,				// Font height
                   0,								// Default font width
                   FW_NORMAL,						// Font weight
                   1,								// Not using MipLevels
                   false,							// Don't use italic font
                   DEFAULT_CHARSET,					// Default character set
                   OUT_DEFAULT_PRECIS,				// Default outputPrecision
                   DEFAULT_QUALITY,					// Default quality
                   DEFAULT_PITCH | FF_DONTCARE,		// Default pitch and family
                   L"Arial",						// Use Facename Arial
                   &font);

	SetRect(&textbox, 0, WIN_HEIGHT-210, WIN_WIDTH, WIN_HEIGHT);	// 10 lines of 21 sized font

	// Load the terrain
	LoadMesh(&meshes[0], &material, &texture, &numMaterials, L"meshes/orc_zone.x");

	// Init animation meshes here
	animated = new AnimatedMesh();
	animated->InitMesh(L"meshes/tiny.x");
}


//-----------------------------------------------------------------------------
// Name: InitNetwork()
// Desc: Initializes the network connections
//-----------------------------------------------------------------------------
void InitNetwork()
{
	//message = NULL;
	message = "hey there!\0";
	network = new Network();

	network->InitNetwork();
}


//-----------------------------------------------------------------------------
// Name: DoInput()
// Desc: Encapsulates the outcome of the input the player can send
//-----------------------------------------------------------------------------
void DoInput()
{
	// Apply camera (and thus player) movement when not chatting
	if(true)//)state == STATE_PLAYING)
	{
		if (KEY_DOWN(DIK_LEFT))		{ camera->LookLeft(); }
		if (KEY_DOWN(DIK_RIGHT))	{ camera->LookRight(); }
		if (KEY_DOWN(DIK_UP))		{ camera->LookUp(); }
		if (KEY_DOWN(DIK_DOWN))		{ camera->LookDown(); }
		if (KEY_DOWN(DIK_W))		{ camera->MoveForward(); }
		if (KEY_DOWN(DIK_S))		{ camera->MoveBack(); }
		if (KEY_DOWN(DIK_A))		{ camera->MoveLeft(); }
		if (KEY_DOWN(DIK_D))		{ camera->MoveRight(); }
	}

	// Toggle chatting when return is pressed
	if (!KEY_DOWN(DIK_RETURN))	{ returnPressed = false; }
	if (KEY_DOWN(DIK_RETURN) && !returnPressed)		
	{
		returnPressed = true;
		if(state == STATE_PLAYING)
			state = STATE_TYPING;
		else if (state == STATE_TYPING)
		{
			//message = NULL;
			state = STATE_PLAYING;
		}
	}

	// Update the meshes in case the camera moved
	camera->UpdateMeshList(meshes[0], 1);
}




//-----------------------------------------------------------------------------
// Name: DoLogic()
// Desc: Does the logic and natural forces of the game world
//-----------------------------------------------------------------------------
void DoLogic()
{
	// Apply gravity to the camera 
	camera->ApplyGravity(); // TODO: Later.  Move to camera only when moving eventually
}




//-----------------------------------------------------------------------------
// Name: DoNetwork()
// Desc: Does a network cycle
//-----------------------------------------------------------------------------
void DoNetwork()
{
	network->Send();
}



//-----------------------------------------------------------------------------
// Name: RenderFrame()
// Desc: Draws a frame
//-----------------------------------------------------------------------------
VOID RenderFrame()
{
    if( NULL == d3dDevice )
        return;

    // Clear the backbuffer to the background colour
    d3dDevice->Clear( 0, NULL, D3DCLEAR_TARGET, BACKGROUND_COLOUR, 1.0f, 0 );
	d3dDevice->Clear( 0, NULL, D3DCLEAR_ZBUFFER, D3DCOLOR_XRGB(0, 0, 0), 1.0f, 0);

    // Begin the scene
    if( SUCCEEDED( d3dDevice->BeginScene() ) )
    {
		// Set the view
		D3DXMATRIX matView;

		// Point the camera in the right direction
		D3DXMatrixLookAtLH(&matView,
                   &(camera->GetPosition()),	// the camera position
                   &(camera->GetLookat()),		// the look-at position
                   &VEC_UP);					// the up direction

		d3dDevice->SetTransform(D3DTS_VIEW, &matView);

		// Set the projection
		D3DXMATRIX matProjection;

		D3DXMatrixPerspectiveFovLH(&matProjection,
				   D3DXToRadian(45),			// the horizontal field of view
				   WIN_ASPECT,					// aspect ratio
				   NUM_VIEW_NEAR,				// the near view-plane
				   NUM_VIEW_FAR);				// the far view-plane

		d3dDevice->SetTransform(D3DTS_PROJECTION, &matProjection);

		// Draw the terrain mesh
		for(DWORD i = 0; i < numMaterials; i++) // TODO: Later.  Create a terrain class
		{
			d3dDevice->SetMaterial(&material[i]);
			if (texture[i] != NULL)
				d3dDevice->SetTexture(0, texture[i]);
			meshes[0]->DrawSubset(i);
		}

		// Draw the people playing with you
		for(int i = 0; i < MAX_CLIENTS; i++)
			network->clients[i]->DrawMesh();

		// Draw the SkyBox
		camera->DrawSkybox(); // TODO: Make the skybox scale with the far clipping plane

		// Draw the animated mesh here
		animated->DrawMesh();

		// Begin drawing the HUD
		d3dSprite->Begin(D3DXSPRITE_ALPHABLEND);
			
			// Adjust text box alpha
			if(state == STATE_TYPING)
			{
				if(textboxA < TEXTBOX_MAX_ALPHA)	{ textboxA += 10; }
			}
			else if (state == STATE_PLAYING)
			{
				if(textboxA > 0)					{ textboxA -= 10; }
			}
				
			if(textboxA < 0)						{ textboxA = 0; }
			if(textboxA > TEXTBOX_MAX_ALPHA)		{ textboxA = TEXTBOX_MAX_ALPHA; }

			// Give the text box a background
			D3DXVECTOR3 position(0.0f, textbox.top, 0.0f);
			d3dSprite->Draw(sprTextbox, &textbox, NULL, &position, D3DCOLOR_ARGB(textboxA, 255, 255, 255));

		d3dSprite->End();

		RECT tempbox = textbox;

		for(int i = 0; i < MAX_MESSAGES; i++)
		{
			if(network->messages[i] != NULL)
			{
				font->DrawTextA(NULL,
							  network->messages[i],
							  -1,
							  &tempbox,
							  DT_LEFT | DT_BOTTOM | DT_WORDBREAK,
							  D3DCOLOR_ARGB(textboxA*2, TEXT_R, TEXT_G, TEXT_B));

				tempbox.bottom -= CHAT_FONT_HEIGHT;
			}
		}

        // End the scene
        d3dDevice->EndScene();
    }

    // Present the backbuffer contents to the display
    d3dDevice->Present( NULL, NULL, NULL, NULL );
}




//-----------------------------------------------------------------------------
// Name: InitLight()
// Desc: Initializes the light and material of the scene
//-----------------------------------------------------------------------------
void InitLight()
{
	D3DLIGHT9 light;
	D3DMATERIAL9 material;

	ZeroMemory(&light, sizeof(light));
	light.Type = D3DLIGHT_DIRECTIONAL;
	light.Diffuse = D3DXCOLOR(0.5f, 0.5f, 0.5f, 1.0f); // light's colour
	light.Direction = D3DXVECTOR3(-1.0f, -0.3f, -1.0f);

	d3dDevice->SetLight(0, &light); // Send properties to light 0
	d3dDevice->LightEnable(0, TRUE); // Turn light 0 on

	ZeroMemory(&material, sizeof(D3DMATERIAL9));
	material.Diffuse = D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f);
	material.Ambient = D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f);

	d3dDevice->SetMaterial(&material);
}






//-----------------------------------------------------------------------------
// Name: DetectInput()
// Desc: Finds input via DirectInput
//-----------------------------------------------------------------------------
void DetectInput()
{
	// Get access
	dinkeyboard->Acquire();

	// Get data
	dinkeyboard->GetDeviceState(256, (LPVOID)keystate);
}




//-----------------------------------------------------------------------------
// Name: InitD3D()
// Desc: Initializes Direct3D and it's properties
//-----------------------------------------------------------------------------
HRESULT InitD3D( HWND hWnd )
{
    // Create the D3D object, which is needed to create the D3DDevice.
    if( NULL == ( D3D = Direct3DCreate9( D3D_SDK_VERSION ) ) )
        return E_FAIL;

    // Set up the structure used to create the D3DDevice
    D3DPRESENT_PARAMETERS d3dpp;
    ZeroMemory( &d3dpp, sizeof( d3dpp ) );
    d3dpp.Windowed = TRUE;
    d3dpp.SwapEffect = D3DSWAPEFFECT_DISCARD;
	d3dpp.hDeviceWindow = hWnd;
    d3dpp.BackBufferFormat = D3DFMT_X8R8G8B8;
	d3dpp.BackBufferWidth = WIN_WIDTH;
	d3dpp.BackBufferHeight = WIN_HEIGHT;
	d3dpp.EnableAutoDepthStencil = TRUE;
	d3dpp.AutoDepthStencilFormat = D3DFMT_D16;

    // Create the Direct3D device. Here we are using the default adapter (most
    // systems only have one, unless they have multiple graphics hardware cards
    // installed) and requesting the HAL (which is saying we want the hardware
    // device rather than a software one). Software vertex processing is 
    // specified since we know it will work on all cards. On cards that support 
    // hardware vertex processing, though, we would see a big performance gain 
    // by specifying hardware vertex processing.
    if( FAILED( D3D->CreateDevice( D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, hWnd,
                                      D3DCREATE_SOFTWARE_VERTEXPROCESSING,
                                      &d3dpp, &d3dDevice ) ) )
    {
        return E_FAIL;
    }

    // Device state would normally be set here
	InitGraphics();
	InitLight();
	
	// Set up render states
	d3dDevice->SetRenderState(D3DRS_LIGHTING, TRUE); // lighting on
	d3dDevice->SetRenderState(D3DRS_AMBIENT, D3DCOLOR_XRGB(50, 50, 50)); // ambient light
	d3dDevice->SetRenderState(D3DRS_ZENABLE, TRUE); // z-buffer on
	d3dDevice->SetRenderState(D3DRS_NORMALIZENORMALS, TRUE); // normalize normals
	//		colour blending is off right now
	//d3dDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE); // colour blending
	//d3dDevice->SetRenderState(D3DRS_BLENDOP, D3DBLENDOP_ADD); // set the blending operation
	//d3dDevice->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA); // define the blending source
	//d3dDevice->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA); // define the blending destination

	// Set up sampling states
	d3dDevice->SetSamplerState(0, D3DSAMP_MAXANISOTROPY, 8); // anisotropic level
	d3dDevice->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_ANISOTROPIC); // minification
	d3dDevice->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR); // magnification
	d3dDevice->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR); // mipmap

    return S_OK;
}




//-----------------------------------------------------------------------------
// Name: InitDirectInput()
// Desc: Initializes DirectInput for the keyboard
//-----------------------------------------------------------------------------
HRESULT InitDirectInput(HINSTANCE hInst, HWND hWnd)
{
	// Create the DirectInput interface
	DirectInput8Create(hInst,
			DIRECTINPUT_VERSION,
			IID_IDirectInput8,
			(void**)&din,
			NULL);

	// Create the keyboard
	din->CreateDevice(GUID_SysKeyboard,
			&dinkeyboard,
			NULL);

	// Set the data to keyboard format
	dinkeyboard->SetDataFormat(&c_dfDIKeyboard);

	// Set the control level over the keyboard
	dinkeyboard->SetCooperativeLevel(hWnd,
			(DISCL_FOREGROUND | DISCL_NONEXCLUSIVE));

	return S_OK;
}




//-----------------------------------------------------------------------------
// Name: MsgProc()
// Desc: The window's message handler
//-----------------------------------------------------------------------------
LRESULT WINAPI MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
    switch( msg )
    {
        case WM_DESTROY:
			{
				PostQuitMessage( 0 );
				return 0;
			} break;
    }

    return DefWindowProc( hWnd, msg, wParam, lParam );
}




//-----------------------------------------------------------------------------
// Name: wWinMain()
// Desc: The application's entry point
//-----------------------------------------------------------------------------
INT WINAPI wWinMain( HINSTANCE hInst, HINSTANCE, LPWSTR, INT )
{
    // Register the window class
    WNDCLASSEX wc =
    {
        sizeof( WNDCLASSEX ), CS_CLASSDC, MsgProc, 0L, 0L,
        GetModuleHandle( NULL ), NULL, NULL, NULL, NULL,
        APP_NAME, NULL
    };
    RegisterClassEx( &wc );

    // Create the application's window
    HWND hWnd = CreateWindow( APP_NAME, WINDOW_NAME,
                              WS_OVERLAPPEDWINDOW, 200, 200, WIN_WIDTH, WIN_HEIGHT,
                              NULL, NULL, wc.hInstance, NULL );

	ShowWindow( hWnd, SW_SHOWDEFAULT );

    // Initialize Direct3D
    if(SUCCEEDED(InitD3D(hWnd)) && SUCCEEDED(InitDirectInput(hInst, hWnd)))
    {
		MSG msg;

		InitGameplay();
		InitNetwork();

		// Run the main loop
		while(TRUE)
		{
			while(PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
			{
				TranslateMessage(&msg);
				DispatchMessage(&msg);
			}

			if(msg.message == WM_QUIT)
				break;

			DetectInput();
			DoInput();
			DoLogic();
			DoNetwork();
			RenderFrame();

			if(KEY_DOWN(DIK_ESCAPE))
				PostMessage(hWnd, WM_DESTROY, 0, 0);
		}

		// Post-main-loop events
		Cleanup();

		return msg.wParam;
    }

	return 0;
}



//-----------------------------------------------------------------------------
// Name: Cleanup()
// Desc: Releases all previously initialized objects
//-----------------------------------------------------------------------------
VOID Cleanup()
{
	SAFE_RELEASE(font);
	
	SAFE_UNACQUIRE(dinkeyboard);	// Keyboard input
	SAFE_RELEASE(din);				// DirectInput

	SAFE_RELEASE((*texture));		// Terrain textures
	SAFE_RELEASE(meshes[0]);		// Terrain

	SAFE_DELETE(network);			// Network handler

    SAFE_RELEASE(d3dDevice);		// Direct3D Device
    SAFE_RELEASE(D3D);				// Direct3D
}
