#include "network.h"

Network::Network()		{ SizeInt = sizeof(ServerAddress); }
Network::~Network()		{}

void Network::InitNetwork()
{
	// Initialize the messages to be blank
	for(int i = 0; i < MAX_MESSAGES; i++)
		messages[i] = NULL;

	// Initialize the clients' data structures and put them out of the way
	for(int i = 0; i < MAX_CLIENTS; i++)
	{
		clients[i] = new Character(L"meshes/human.x");
		clients[i]->SetPosDir(	D3DXVECTOR3(0.0f, -1000.0f, 0.0f), // Make it out of the way until it's repositioned
								D3DXVECTOR3(1.0f, 0.0f, 0.0f)		);
	}

	// Initialize the Winsock stuff
	WSAStartup(MAKEWORD(2, 2), &Winsock);								// Start Winsock

	if(LOBYTE(Winsock.wVersion) != 2 || HIBYTE(Winsock.wVersion) != 2)	// Check version
		WSACleanup();

	Socket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);

	ZeroMemory(&ServerAddress, sizeof(ServerAddress));			// Zero the struct
	ServerAddress.sin_family = AF_INET;							// Set the address family
	ServerAddress.sin_addr.s_addr = inet_addr(SERVER_ADDRESS);	// Set the IP address
	ServerAddress.sin_port = SERVER_PORT;						// Set the port

	Knock();
}

void Network::Knock()
{
	// Tell the server we're logging on
	SendBuffer[BYT_HEADER] = KEY_LOG_ON;
	sendto(Socket, SendBuffer, PACKET_SIZE, 0, (sockaddr*)&ServerAddress, sizeof(sockaddr));

	// Initialize the receiving threads
	CreateThread(NULL, 0, ThreadEntry, this, 0, NULL);

	// Print a welcome message
	for(int i = 9; i > 0; i--)
		messages[i] = messages[i-1];
	messages[0] = "You've joined the network.";
}

void Network::Release()
{
	// Tell the server that we are leaving
	SendBuffer[BYT_HEADER] = KEY_LOG_OFF;
	sendto(Socket, SendBuffer, PACKET_SIZE, 0, (sockaddr*)&ServerAddress, sizeof(sockaddr));

	// Clean up Winsock
	WSACleanup();
}

void Network::Send()
{
	// Send your position
	SendBuffer[BYT_HEADER] = KEY_POSITION;
	memcpy(&SendBuffer[BYT_X], &(camera->GetPosition().x), 4);
	memcpy(&SendBuffer[BYT_Y], &(camera->GetPosition().y), 4);
	memcpy(&SendBuffer[BYT_Z], &(camera->GetPosition().z), 4);
	sendto(Socket, SendBuffer, PACKET_SIZE, 0, (sockaddr*)&ServerAddress, sizeof(sockaddr));

	// Send your direction
	SendBuffer[BYT_HEADER] = KEY_DIRECTION;
	memcpy(&SendBuffer[BYT_X], &(camera->GetDirection().x), 4);
	memcpy(&SendBuffer[BYT_Y], &(camera->GetDirection().y), 4);
	memcpy(&SendBuffer[BYT_Z], &(camera->GetDirection().z), 4);
	sendto(Socket, SendBuffer, PACKET_SIZE, 0, (sockaddr*)&ServerAddress, sizeof(sockaddr));
}

int Network::RecvThread()
{
	// Retain positions and directions to prevent mesh "flickering"
	D3DXVECTOR3 positions[MAX_CLIENTS];
	D3DXVECTOR3 directions[MAX_CLIENTS];

	while (true)
	{
		// Wait for messages
		recvfrom(Socket, RecvBuffer, PACKET_SIZE, 0, (sockaddr*)&ServerAddress, &SizeInt);

		// If it's a position message...
		if(RecvBuffer[BYT_HEADER] == KEY_POSITION)
		{
			int clientIndex = RecvBuffer[BYT_CLIENTID];

			// Set the position data
			memcpy(&positions[clientIndex].x, &RecvBuffer[BYT_X], 4);
			memcpy(&positions[clientIndex].y, &RecvBuffer[BYT_Y], 4);
			memcpy(&positions[clientIndex].z, &RecvBuffer[BYT_Z], 4);
			clients[clientIndex]->SetPosDir(positions[clientIndex], directions[clientIndex]);
		}

		// If it's a direction message...
		if(RecvBuffer[BYT_HEADER] == KEY_DIRECTION)
		{
			int clientIndex = RecvBuffer[BYT_CLIENTID];

			// Set the direction data
			memcpy(&directions[clientIndex].x, &RecvBuffer[BYT_X], 4);
			memcpy(&directions[clientIndex].y, &RecvBuffer[BYT_Y], 4);
			memcpy(&directions[clientIndex].z, &RecvBuffer[BYT_Z], 4);
			clients[clientIndex]->SetPosDir(positions[clientIndex], directions[clientIndex]);
		}

		// Quit the thread if we tell the server we're leaving
		if(RecvBuffer[BYT_HEADER] == KEY_LOG_OFF)
			break;
	}

	return 0;
}