#ifndef NETWORK
#define NETWORK

#define _WINSOCKAPI_
#include <winsock2.h>
#include <stdio.h>		// Used for data manipulation
#include <stdlib.h>		// Used for data manipulation
#include "camera.h"		// The global camera needs to be accessed
//#include "character.h" Already included (camera->collision_detection->character)
#include <time.h>		// Used for messages at intervals

#define MAX_MESSAGES	10

// Various server data
#define SERVER_ADDRESS		"192.168.1.64"
#define CHAT_SERVER_ADDRESS	"192.168.1.64"
#define SERVER_PORT			17000	// The following variables must match with server's main.cpp definitions
#define CHAT_SERVER_PORT	18000
#define PACKET_SIZE			16
#define CHAT_PACKET_SIZE	256
#define MAX_CLIENTS			8

#define KEY_LOG_ON		1		// LOG_ON:		1 byte key, 15 bytes ignored
#define KEY_LOG_OFF		2		// LOG_OFF:		1 byte key, 15 bytes ignored
#define KEY_POSITION	3		// POSITION:	1 byte key, 1 byte client ID, 12(4x3) bytes position data, 1 byte ignored
#define KEY_DIRECTION	4		// DIRECTION:	1 byte key, 1 byte client ID, 12(4x3) bytes direction data, 1 byte ignored

#define BYT_HEADER		0
#define BYT_CLIENTID	1
#define BYT_X			2
#define BYT_Y			7
#define BYT_Z			12
#define BYT_MESSAGE		1

extern LPCAMERA camera;				// Data is taken from the camera and sent to the server

//-----------------------------------------------------------------------------
// Class: Network
// Desc: Does everything needed on the client side of the network
//-----------------------------------------------------------------------------
class Network
{
public:
	Network();
	~Network();

	void InitNetwork();					// Sets up the network
	void Send();						// Sends all relevant data to the network
	void Release();						// Shuts down the network

	LPCHARACTER clients[MAX_CLIENTS];	// A ledger of all the clients on the server
	char* messages[MAX_MESSAGES];		// A list of the chat messages recieved

private:
	WSADATA Winsock;					// Stores information about Winsock
	SOCKET Socket;						// The socket we'll send game data through
	sockaddr_in ServerAddress;			// The address of the server
	char SendBuffer[PACKET_SIZE];		// The data sent
	char RecvBuffer[PACKET_SIZE];		// The data received
	int SizeInt;						// The size of the server address

	// TODO: Add GUIDs so the server can identify by networks instead of by IPs, allowing multiple logins per computer for development

	// Needed to point the threads at a class function
	static DWORD WINAPI ThreadEntry(LPVOID n)
	{
		return ((Network*)n)->RecvThread();
	}

	void Knock();				// Tells the server to log us in
	int RecvThread();			// Contains the loop to listen and react to incoming data
};

typedef Network* LPNETWORK;

#endif