#include "npc.h"

Npc::Npc()		{}
Npc::Npc(D3DXVECTOR3 startLoc, D3DXVECTOR3 startDir, LPDIRECT3DDEVICE9 d3dDevice)
{
	character->SetPosDir(startLoc, startDir);
	this->Position = startLoc;

	character->InitMesh(L"meshes/human.x");
}

Npc::~Npc()
{
	delete character;
}

void Npc::Draw()
{
	character->DrawMesh();
}