#ifndef NPC
#define NPC

#include <d3d9.h>
#include <d3dx9.h>
#include "collision_detection.h"	// Npc inherits Collidable

//-----------------------------------------------------------------------------
// Class: Npc
// Desc: Logic and behaviour of NPC characters
//-----------------------------------------------------------------------------
class Npc : public Collidable
{
public:
	// Constructors and destructors
	Npc();
	Npc(D3DXVECTOR3 startLoc, D3DXVECTOR3 startDir, LPDIRECT3DDEVICE9 d3dDevice);
	~Npc();

	// Draw the character
	void Draw();
};

typedef Npc* LPNPC;

#endif