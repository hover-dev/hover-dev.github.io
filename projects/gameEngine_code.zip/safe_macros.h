#ifndef SAFE
#define SAFE

// These are just a few helper functions to avoid errors when we don't know (or care) if an object will exist when deleting them

#define SAFE_DELETE(p) {if(p) {delete(p); (p)=NULL;}}
#define SAFE_DELETE_ARRAY(p) {if(p) {delete[](p); (p)=NULL;}}
#define SAFE_RELEASE(p) {if(p) {p->Release();}}
#define SAFE_UNACQUIRE(p) {if(p) {p->Unacquire();}}

#endif