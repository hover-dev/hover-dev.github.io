#ifndef X_CONSTS
#define X_CONSTS

#define SUBSETS_TO_DRAW			4

#define INDEX_BODY				0
#define INDEX_HEAD				1
#define INDEX_TORSO				2
#define INDEX_PANTS				3

#define SUBSET_BODY				0
#define SUBSET_HEAD_1			5
#define SUBSET_LEATHER_CHEST	3
#define SUBSET_LEATHER_PANTS	1

#endif