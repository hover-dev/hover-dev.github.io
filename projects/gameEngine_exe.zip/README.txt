This application was made with DirectX9 libraries, the March 2009 build I believe.  I won't include the installer here, but hopefully you already have it installed.  As well, I believe the build of this application was made with the debug libraries.

   - Justin Scott