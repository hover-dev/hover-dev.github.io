_WASD_
Move the character

_Space_
Dig out the space in front of the character.  Warning, this costs endurance and won't if your endurance meter gets too low.

_Q_
Generate a new island

_E_
Drop a torch

_Tab_
Open extended GUI, the two boxes beside the health bar which are currently unused

_Esc_
Quit the game and save the current map

_Left Click_
Dig out the highlighted block