/***********************************************************
 * CMPT 361, Spring 2007
 *
 *  raycast.cpp
 *      
 *  Render a simple scene using ray tracing
 * 
 *  NAME: Justin Scott
 *  SFU ID: 301030339
 *
 *  Template code for drawing a scene using raycasting.
 *  Some portions of the code was originally written by 
 *  M. vandePanne - and then modified by R. Zhang
***********************************************************/

#ifdef WIN32
#include <windows.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gl/glut.h>
#include "trace.h"
#include "global.h"
#include "sphere.h"
#include "image_util.h"
#include "scene.h"

//
// Here we avoid dynamic memory allocation as a convenience. You can
// change the resolution of your rendered image by changing the values
// of WIN_X_SIZE and WIN_Y_SIZE in "global.h", along with other
// global variables
//

int win_width = WIN_WIDTH;
int win_height = WIN_HEIGHT;

GLfloat frame[WIN_HEIGHT][WIN_WIDTH][3];   
                       // array for the final image - this gets displayed by
                       // glDrawPixels(...). Note that the first dimension
                       // corresponds to the rows of the array and also the
                       // image window, which turns out to be the height

float image_width = IMAGE_WIDTH;
float image_height = (float(WIN_HEIGHT) / float(WIN_WIDTH)) * IMAGE_WIDTH;

// some colors
RGB_float background_clr; // background color
RGB_float null_clr = {0.0, 0.0, 0.0};   // NULL color

//
// these view parameters should be fixed
//
Point eye_pos = {0.0, 0.0, 0.0};  // eye position
float image_plane = -2;           // image plane position

// list of spheres in the scene
Spheres *scene = NULL;

// light 1 position and color
Point light1;
float light1_ambient[3];
float light1_diffuse[3];
float light1_specular[3];

// global ambient term
float global_ambient[3];

// light decay parameters
float decay_a;
float decay_b;
float decay_c;

// maximum level of recursions; you can use to control whether reflection
// is implemented and for how many levels
int step_max = 1;

int shadow_on = 0;			// a flag for shadows
int reflection_on = 0;		// a flag for reflections
int refraction_on = 0;		// a flag for refraction
int diffuse_on = 0;			// a flag for diffusion
int supersample_on = 0;		// a flag for super-sampling
int checkerb_on = 0;		// a flag for the checkerboard

/*********************************************************
 * This function handles keypresses
 *
 *   S - save image
 *   q - quit
 *
 * DO NOT CHANGE
 *********************************************************/
void keyboard(unsigned char key, int x, int y)
{
  switch (key) {
    case 'q':
      free(scene);
      exit(0);
      break;
    case 'S':
      save_image();
      glutPostRedisplay();
      break;
    default:
      break;
  }
}

/*********************************************************
 * This function performs most of the OpenGL intialization
 * There should be no need to change anything here.
 **********************************************************/
void myinit(void) {
  glClearColor(0.0, 0.0, 0.0, 0.0);

  glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
}

/*********************************************************
 * This is the OpenGL display function. It is called by
 * the event handler to draw the scene after you have
 * rendered the image using ray tracing. Remember that
 * the pointer to the image memory is stored in 'frame'.
 *
 * There is no need to change this.
 **********************************************************/
void display(void) {
  GLboolean param;

  glLoadIdentity();

  glClear(GL_COLOR_BUFFER_BIT); // clear the background

  glRasterPos2i(0, 0);
  glGetBooleanv(GL_CURRENT_RASTER_POSITION_VALID, &param);
  if (!frame){
    printf("frame is null. \n");
  } else {
    glDrawPixels(win_width, win_height, GL_RGB, GL_FLOAT, frame);
  }
  
  glFlush();
}

/*********************************************************
 * This handles the window being resized -- DO NOT CHANGE
 **********************************************************/
void myReshape(int w, int h) {
  w = win_width;
  h = win_height;

  glViewport(0, 0, w, h);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  gluOrtho2D(0, w, 0, h);
  glMatrixMode(GL_MODELVIEW);
}

/*********************************************************
 * Main function: calls initialization, then hands over
 * control to the event handler, which calls display()
 * whenever the screen needs to be redrawn. Of course,
 * the scene to be drawn is decided by your ray tracer
 *
 * You should not need to change this.
 **********************************************************/
int main(int argc, char** argv) {
  glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH);
  glutInitWindowPosition (0, 0);
  glutInitWindowSize(win_width, win_height);
  glutCreateWindow(argv[0]);
  myinit();
  glutReshapeFunc(myReshape);
  glutKeyboardFunc(keyboard);

  if (argc < 3) {
    printf("Missing arguments ... use:\n");
    printf("./raycast [-u | -d] step_max <options>\n");
    return -1;
  }

  // set up the scene
  if (strcmp(argv[1], "-u") == 0) {  // user defined scene
    set_up_user_scene();
  } else { // use default scene
    set_up_default_scene();
  }

  step_max = atoi(argv[2]);

  // Go through every optional variable and alter their toggles
  for (int i = 3; i < argc; i++)
  {
	if (strcmp(argv[i],"+s") == 0) shadow_on = 1;
	else if (strcmp(argv[i],"+l") == 0) reflection_on = 1;
	else if (strcmp(argv[i],"+r") == 0) refraction_on = 1;
	else if (strcmp(argv[i],"+c") == 0) checkerb_on = 1;
	else if (strcmp(argv[i],"+f") == 0) diffuse_on = 1;
	else if (strcmp(argv[i],"+p") == 0) supersample_on = 1;
  }

  glutDisplayFunc(display);
  printf("Rendering the scene using my fantastic ray tracer ...\n");

  //
  // ray trace the scene now
  //
  // we have used so many global variables and this function is
  // happy to carry no parameters
  //
  ray_trace();

  // we want to make sure that intensity values are normalized
  histogram_normalization();

  printf("Finished!\n");
  printf("Press 'S' to save image\n");
  printf("Press 'q' to quit\n");

  glutMainLoop();
  return 0;
}
