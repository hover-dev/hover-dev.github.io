void set_up_default_scene();
void set_up_user_scene();
