//debug
#include <iostream>
#define NUM_RANDOM_RAYS 5

//random number generation
#include <stdlib.h>
#include <time.h>

#include <stdio.h>
#include <gl/glut.h>
#include <math.h>
#include "global.h"
#include "sphere.h"

//
// Global variables
//
extern int win_width;
extern int win_height;

extern GLfloat frame[WIN_HEIGHT][WIN_WIDTH][3];  

extern float image_width;
extern float image_height;

extern Point eye_pos;
extern float image_plane;
extern RGB_float background_clr;
extern RGB_float null_clr;

extern Spheres *scene;

// light 1 position and color
extern Point light1;
extern float light1_ambient[3];
extern float light1_diffuse[3];
extern float light1_specular[3];

// global ambient term
extern float global_ambient[3];

// light decay parameters
extern float decay_a;
extern float decay_b;
extern float decay_c;

extern int shadow_on;
extern int reflection_on;
extern int refraction_on;
extern int diffuse_on;
extern int supersample_on;
extern int checkerb_on;

extern int step_max;
RGB_float white = {2,2,2};
RGB_float black = {0,0,0};

/////////////////////////////////////////////////////////////////////

/*********************************************************************
 * Phong illumination - you need to implement this!
 *********************************************************************/
RGB_float phong(Point q, Vector v, Point ph_hit, Spheres *sph) {
	// NOTE: The function is changed.  The surface normal is calculated
	//		 within the phong function, but the point of intersection
	//		 has already been found in the recursive ray tracing function
	//		 as well as the sphere intersected with.

	// I probably could cut down on the variables defined here, but I think it
	// much clearer and simpler in the long run

	Vector N = sphere_normal(ph_hit,sph);						//surface normal
	Vector L = get_vec(ph_hit,light1);							//light vector
	normalize(&L);
	Vector R = vec_minus( vec_scale(N,2*vec_dot(N,L)) , L );	//reflection vector
	Vector V = get_vec(ph_hit,eye_pos);							//view vector
	normalize(&R);
	normalize(&V);
	float a = decay_a;											//decay rate a
	float b = decay_b;											//decay rate b
	float c = decay_c;											//decay rate c
	float n = sph->mat_shineness;								//shininess parameter
	float d = vec_len(L);										//distance between light and point
	float Iga[3] = {global_ambient[0],							//global ambient light
					global_ambient[1],
					global_ambient[2]};		
	float Kga[3] = {1,											//object's coefficient for global ambient light
					1,
					1};
	float Ia[3] = {light1_ambient[0],							//object ambient
					light1_ambient[1],
					light1_ambient[2]};
	float Ka[3] = {sph->mat_ambient[0],							//ambience coeff.
					sph->mat_ambient[1],
					sph->mat_ambient[2]};
	float Id[3] = {light1_diffuse[0],							//object diffuse
					light1_diffuse[1],
					light1_diffuse[2]};
	float Kd[3] = {sph->mat_diffuse[0],							//diffuse coeff.
					sph->mat_diffuse[1],
					sph->mat_diffuse[2]};
	float Is[3] = {light1_specular[0],							//object specular
					light1_specular[1],
					light1_specular[2]};
	float Ks[3] = {sph->mat_specular[0],						//specular coeff.
					sph->mat_specular[1],
					sph->mat_specular[2]};

	RGB_float colour;
	float X = (0>vec_dot(R,V)) ? 0 : vec_dot(R,V);
	colour.r = Iga[0]*Kga[0] + ((Ia[0]*Ka[0] + Id[0]*Kd[0]*vec_dot(N,L) + Is[0]*Ks[0]*pow(X,n))/(a + b*d + c*d*d));
	colour.g = Iga[1]*Kga[1] + ((Ia[1]*Ka[1] + Id[1]*Kd[1]*vec_dot(N,L) + Is[1]*Ks[1]*pow(X,n))/(a + b*d + c*d*d));
	colour.b = Iga[2]*Kga[2] + ((Ia[2]*Ka[2] + Id[2]*Kd[2]*vec_dot(N,L) + Is[2]*Ks[2]*pow(X,n))/(a + b*d + c*d*d));
	
	return colour;
}

/************************************************************************
 * This is the recursive ray tracer - you need to implement this!
 * You should decide what arguments to use.
 ************************************************************************/
RGB_float recursive_ray_trace(int step, Point o, Vector u, Spheres *slist) {
	// Get intersection point of ray and sphere
	Point hit;
	Spheres *sph = intersect_scene(o,u,slist,&hit);

	// Make sure there is an intersection
	// Otherwise return either the background or the checkerboard
	if (sph == NULL)
	{
		if (checkerb_on == 0) return background_clr;
		else
		{
			// Used to help with shadows
			bool done = false;

			// Find intersections with the checkerboard
			Vector norm = {0,1,0};
			Point plane = {0,-4,0};

			float b = vec_dot(norm,u); // 0 if no intersection
			if (b < 0)
			{
				// Get the specific point it intersects at 
				Vector v = get_vec(o,plane);
				float a = vec_dot(norm,v);
				a = a/b;

				// 8x8 checkerboard restraints
				float xmin = -6;
				float xmax = 6;
				float zmin = -15;
				float zmax = -3;
				float zwidth = (zmax-zmin) / 8;
				float xwidth = (xmax-xmin) / 8;

				// Set the point that is intersected
				hit = get_point( eye_pos , vec_scale(u,a) );

				// Colour in the parts the right colours
				RGB_float ret = {1,0,0};
				if (hit.x < xmax && hit.x > xmin && hit.z < zmax && hit.z > zmin)
				{
					// Determine if it's a shadow area, which will return black if shadows are on
					Vector l = get_vec(hit,light1);

					int x = (hit.x-xmin)/xwidth;
					int z = (hit.z-zmin)/zwidth;

					if (done == false)
					{
						if (x%2 == 0 && z%2 == 0) ret = white;
						else if (x%2 == 1 && z%2 == 1) ret = white;
						else ret = black;
						
						// Using a specialized phong shading method
						float a = decay_a;											//decay rate a
						float b = decay_b;											//decay rate b
						float c = decay_c;											//decay rate c
						float Iga[3] = {global_ambient[0],							//global ambient light
										global_ambient[1],
										global_ambient[2]};		
						float Ia[3] = {light1_ambient[0],							//object ambient
										light1_ambient[1],
										light1_ambient[2]};
						float Id[3] = {light1_diffuse[0],							//object diffuse
										light1_diffuse[1],
										light1_diffuse[2]};
						float Is[3] = {light1_specular[0],							//object specular
										light1_specular[1],
										light1_specular[2]};

						Vector R = vec_minus( vec_scale(norm,2*vec_dot(norm,l)) , l );	//reflection vector
						Vector V = get_vec(hit,eye_pos);								//view vector
						normalize(&R);
						normalize(&V);
						float d = vec_len(l)/7; // If we shrink this number with division, we make the board artificially shiny without
												// using the shininess parameter which uses a costly exponent function
						normalize(&l);
						float X = (0>vec_dot(R,V)) ? 0 : vec_dot(R,V);

						int n = 10; // shininess parameter
						ret.r = Iga[0]*ret.r + ((Ia[0]*ret.r + Id[0]*ret.r*vec_dot(norm,l) + Is[0]*ret.r*pow(X,n))/(a + b*d + c*d*d));
						ret.g = Iga[1]*ret.g + ((Ia[1]*ret.g + Id[1]*ret.g*vec_dot(norm,l) + Is[1]*ret.g*pow(X,n))/(a + b*d + c*d*d));
						ret.b = Iga[2]*ret.b + ((Ia[2]*ret.b + Id[2]*ret.b*vec_dot(norm,l) + Is[2]*ret.b*pow(X,n))/(a + b*d + c*d*d));

						if (reflection_on == 1)
						{
							// I do not find the reflection, but rather I use the normal
							// The reason for this is because the reflection will only return
							// the background, and the point of this is to look nice and give
							// an illusion of shininess.  If the spheres were further back from
							// the camera, I would do it the proper way, but as it is there is
							// no reason to use the perfect reflection
							R = norm;
							hit.x = -hit.x;
							RGB_float refl = recursive_ray_trace(step-1,hit,R,slist);
							hit.x = -hit.x;

							RGB_float c1 = clr_scale(ret, 0.6);
							RGB_float c2 = clr_scale(refl, 0.4);
							ret = clr_add(c1,c2);
						}
						
						if (shadow_on == 1)
						{
							Point temp;
							Spheres *light_test = intersect_scene(hit,l,slist,&temp);
							if (light_test != NULL)
							{
								ret = clr_scale(ret,light_test->mat_transparency);
								done = true;
								if (refraction_on == 0) ret = black;
							}
						}
					}

					done = false;
					return ret;
				}
				else return background_clr;
			}
			else return background_clr;
		}
	}

	// Precalculate the colour now that we know there is one
	RGB_float ph = phong(o,u,hit,sph);

	// If reflection is off, there's no need to find the reflected colours
	if (reflection_on == false) step = 0;

	// Determine if it's a shadow area, which will return black if shadows are on
	if (shadow_on == 1  && refraction_on == 0)
	{
		Vector l = get_vec(hit,light1);
		Spheres *light_test = intersect_scene(hit,l,slist,&hit);
		if (light_test != NULL && light_test != sph) return black;
	}

	// Change the colour value (ph) if there's reflections
	if (step > 0)
	{
		//Find the perfect reflection value as in the phong function
		Vector N = sphere_normal(hit,sph);
		Vector R = vec_minus( u , vec_scale(N,2*vec_dot(N,u)) );
		RGB_float rcolour = recursive_ray_trace(step-1,hit,R,slist);

		// Create an array of random vectors to assist diffusion if enabled
		if (diffuse_on == 1)
		{
			Vector norm = sphere_normal(hit,sph);
			Vector r[NUM_RANDOM_RAYS];

			// Make the random rays completely randomly
			for (int i = 0; i < NUM_RANDOM_RAYS; i++)
			{
				srand ( time(NULL)*rand() );
				Point a = {rand(),rand(),rand()};
				Point b = {rand(),rand(),rand()};

				r[i] = get_vec(a,b);
				normalize(&r[i]);

				r[i] = vec_plus(r[i],vec_scale(R,2.5)); // The higher the scale is, the more focused the random rays are
				normalize(&r[i]);
			}

			// Call a ray trace on those rays w/ step-1 and return an averaged colour
			RGB_float colour[NUM_RANDOM_RAYS+1];
			for (int i = 0; i < NUM_RANDOM_RAYS; i++)
			{
				colour[i] = recursive_ray_trace(step-1,hit,r[i],slist);
			}
			colour[NUM_RANDOM_RAYS] = rcolour;

			// Average and return the rays
			for (int i = 1; i < NUM_RANDOM_RAYS+1; i++)
			{
				colour[0] = clr_add(colour[0],colour[i]);
			}
			colour[0].r = colour[0].r/(NUM_RANDOM_RAYS+1);
			colour[0].g = colour[0].g/(NUM_RANDOM_RAYS+1);
			colour[0].b = colour[0].b/(NUM_RANDOM_RAYS+1);

			RGB_float c1 = clr_scale( colour[0] , sph->reflectance );
			RGB_float c2 = clr_scale( ph , 1-sph->reflectance );

			ph = clr_add( c1 , c2 );
		}
		else
		{
			RGB_float c1 = clr_scale( rcolour , sph->reflectance );
			RGB_float c2 = clr_scale( ph , 1-sph->reflectance );
			ph = clr_add( c1 , c2 );
		}
	}

	// Apply transparency to the colour if it's on
	if (refraction_on == 1)
	{
		// We're going to get the near and far intersections of the sphere and the distance
		// using a similar method as in intersect_sphere in sphere.cpp
		RGB_float trans = black;
		Vector V = get_vec(sph->center,o);
		float A = vec_dot(u,u);
		float B = vec_dot(vec_scale(V,2),u);
		float C = vec_dot(V,V) - sph->radius*sph->radius;

		// If there's no intersection, return -1.0
		float quad = B*B-(4*A*C);
		if (quad < 0) ph = background_clr;

		// Find the intersections
		else 
		{
			quad = (0-B-sqrt(quad))/(2*A);
			float quad2 = (0-B+sqrt(quad))/(2*A);
			Point a = get_point(o,vec_scale(u,quad));	// First intersection
			Point b = get_point(o,vec_scale(u,quad2));	// Second intersection
			quad = vec_len(get_vec(a,b)) / 2;			// Half the distance between them
			quad = quad/sph->radius;					// Get the ratio of the quad variable to sphere radius

			// Mix the diffuse colour and the behind colour for a glassy effect
			RGB_float diffuse = {sph->mat_diffuse[0],
										sph->mat_diffuse[1],
										sph->mat_diffuse[2]};
			RGB_float behind;
			behind = recursive_ray_trace(step,b,u,slist);

			// We need to check for shadows if they're on
			if (shadow_on == 1)
			{
				// Shadows on the close side
				Vector l = get_vec(a,light1);
				Spheres *light_test = intersect_scene(a,l,slist,&a);
				if (light_test != NULL && light_test != sph)
				{
					RGB_float c1 = behind;
					RGB_float c2 = black;
					c1 = clr_scale(c1, sph->mat_transparency);
					c2 = clr_scale(c2, 1-sph->mat_transparency);
					ph = clr_add(c1, c2);
				}

				// Shadows on the far side
				l = get_vec(b,light1);
				Spheres *light_test2 = intersect_scene(b,l,slist,&b);
				if (light_test2 != NULL && light_test2 != sph)
				{
					RGB_float c1 = behind;
					RGB_float c2 = black;
					c1 = clr_scale(c1, sph->mat_transparency);
					c2 = clr_scale(c2, 1-sph->mat_transparency);
					behind = clr_add(c1, c2);
				}
			}

			// Scale down the glassy effect with the transparency
			RGB_float c1 = clr_scale( diffuse , 1-sph->mat_transparency );
			RGB_float c2 = clr_scale( behind , sph->mat_transparency );
			diffuse = clr_add( c1 , c2 );

			c1 = clr_scale( diffuse , 1-quad );
			c2 = clr_scale( behind , quad );

			trans = clr_add( c1 , c2 );
		}

		RGB_float c1 = clr_scale( ph , 1-sph->mat_transparency );
		RGB_float c2 = clr_scale( trans , sph->mat_transparency );
		ph = clr_add( c1 , c2 );
	}
	return ph;
}

/*********************************************************************
 * This function traverses all the pixels and cast rays. It calls the
 * recursive ray tracer and assign return color to frame
 *
 * You should not need to change it except for the call to the recursive
 * ray tracer. Feel free to change other parts of the function however,
 * if you must.
 *********************************************************************/
void ray_trace() {
  int i, j;
  float x_grid_size = image_width / float(win_width);
  float y_grid_size = image_height / float(win_height);
  float x_start = -0.5 * image_width;
  float y_start = -0.5 * image_height;
  RGB_float ret_color;
  Point cur_pixel_pos;
  Vector ray;

  // Variables used for super-sampling
  RGB_float colours[4];
  Vector rays[4];
  Point pixel_pos;

  // ray is cast through center of pixel
  cur_pixel_pos.x = x_start + 0.5 * x_grid_size;
  cur_pixel_pos.y = y_start + 0.5 * y_grid_size;
  cur_pixel_pos.z = image_plane;
  pixel_pos = cur_pixel_pos;

  for (i=0; i<win_height; i++) {
	std::cout<< (int)(i*100/win_height) <<"%\n";
    for (j=0; j<win_width; j++) {
	  // Find the colour value of the pixel
      ray = get_vec(eye_pos, cur_pixel_pos);
	  ret_color = recursive_ray_trace(step_max,eye_pos,ray,scene);

	  // Generate rays at the corner of the pixel if super-sampling is enabled
	  if (supersample_on == 1)
	  {
		pixel_pos = cur_pixel_pos;
		pixel_pos.x += 0.5 * x_grid_size;
		pixel_pos.y -= 0.5 * y_grid_size;
		rays[0] = get_vec(eye_pos, pixel_pos);
		pixel_pos.x += 1 * x_grid_size;
		rays[1] = get_vec(eye_pos, pixel_pos);
		pixel_pos.y -= 1 * y_grid_size;
		rays[2] = get_vec(eye_pos, pixel_pos);
		pixel_pos.x -= 1 * x_grid_size;
		rays[3] = get_vec(eye_pos, pixel_pos);

		for (int a = 0; a<4; a++)
		{
			colours[a] = recursive_ray_trace(step_max,eye_pos,rays[a],scene);
			ret_color = clr_add(ret_color,colours[a]);
		}
		ret_color.r = ret_color.r / 6;
		ret_color.g = ret_color.g / 6;
		ret_color.b = ret_color.b / 6;
	  }

	  // Return the color values
      frame[i][j][0] = GLfloat(ret_color.r);
      frame[i][j][1] = GLfloat(ret_color.g);
      frame[i][j][2] = GLfloat(ret_color.b);

	  // Move to the next pixel
      cur_pixel_pos.x += x_grid_size;
    }

    cur_pixel_pos.y += y_grid_size;
    cur_pixel_pos.x = x_start;
  }
}
