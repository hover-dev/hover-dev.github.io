void ray_trace();
