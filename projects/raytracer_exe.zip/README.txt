Raycast.exe


[-u | -d]
	-d:	The project's default scene.
	-u:	User defined scene, defined in the source code.

step_max:	How many times a ray should bounce before it's no longer reflected.  2 or 3 is sufficient for most simple scenes.

<options>
	+s:	Add shadows to the scene.
	+l:	Add reflections to the spheres in the scene.
	+r:	Add refraction (transparency) to the spheres in the scene.
	+c:	Add a checkerboard at the bottom of the scen|.
	+f:	Add diffusion to the reflections on the spheres.
	+p:	Render the scene using supersampling.